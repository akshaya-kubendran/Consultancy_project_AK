const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const feed = require('./feedBack')
const connectToDB = require('./connection')
app.set('view engine','ejs');
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.urlencoded({extended: false}));
app.get('/',(req,res)=>{
      res.render('index.ejs')
        
   })
app.post('/submit',async(req,res)=>{
    try{
    const user = req.body;
    console.log(user)  
    // user={"name":"abhishek"}
    await feed.create(user)
    res.render('index.ejs')
    }
    catch(err)
    {
        console.log(err)
    }
     
})
app.listen(3000,()=>connectToDB ()
    .then((data)=>console.log("server is running"))
    .catch((err)=> console.log(err))
    
)