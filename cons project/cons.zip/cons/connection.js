const moongoose = require("mongoose")

const connectToDB = async()=>moongoose.connect("mongodb+srv://akak:akak@cluster0.kwfma.mongodb.net/?retryWrites=true&w=majority",{
    useNewUrlParser:true,
   
    useUnifiedTopology:true,
}).then(() => console.log("DB connected"));

module.exports  = connectToDB 